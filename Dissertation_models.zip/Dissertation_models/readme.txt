Source code for the work is available in the file SahejSareen_210113235_CSC8639_Code.ipynb

Important to read points:


A)DialogueRNN
1. The complete code is in a single file and runnable on python preferably using anconda prompt.

2. Change the path as per the dataset used to the corresponding folders mentioned inside the DialogueRNN_features 

3. Download tensorboardx library from the requirments text file using the command. 'pip install tensorboardx'

4. Execute the file using 'python train_iemocap.py' (for IEMOCAP dataset) and 'python train_meld.py' (for MELD dataset)

5. Each epoch will take approximately 5-7 minutes to execute.


B) bc-LSTM
1.The complete code is in a single file and runnable on python preferably using anconda prompt.

2.Change the path as per the dataset used to the corresponding folders mentioned. eg for IEMACOP us the path for IEMACOP_features_raw

3.Execute the file using python train_iemocap.py (for IEMOCAP dataset) and python train_meld.py (for MELD dataset)

4.Each epoch will take approximately 2-3 minutes to execute.


C)COSMIC
1.The complete code is in a single file and runnable on python preferably using anconda prompt.

2.Change the path as per the dataset used to the corresponding folders mentioned. eg)FOr IEMOCAP use the IEMACOP folder.

2.Execute the file using python train_iemocap.py (for IEMOCAP dataset) and python train_meld.py (for MELD dataset)

3.Each epoch will take approximately 5-7 minutes to execute.


D)Analysis and Visualization
1.This file contains the analysis and the visulaizations of the output.

2. Enter the path of the dataset.


E)SPEECH_SENTIMENT_ANALYSER
1. All the code inside the python notebook should be executed.

2. When the line says "Please speak" then the speaker should speak to give an input. When done the it will automatically stop to process. Furthur lines should be executed to learn the output.

3. If trouble arises try uninstall the Pyaudio by the code !pip uninstall -y Pyaudio and reinstall with !pip install Pyaudio and restart the kernell.




- Kindly mind the processing power and have system connected to power to not loose the progress. 


		